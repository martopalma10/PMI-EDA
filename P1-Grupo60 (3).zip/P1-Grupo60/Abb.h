#ifndef ABB_H
#define ABB_H

#include "elector.h"

// ==========================================
// REGISTRO Y ESTAD�STICAS DE COSTOS (GLOBALES)
// ==========================================

// ALTAS
static float costoMaxAltaABB = 0.0f;
static int totalAltasABB = 0;
static float costoSumaAltaABB = 0.0f;

// BAJAS
static float costoMaxBajaABB = 0.0f;
static int totalBajasABB = 0;
static float costoSumaBajaABB = 0.0f;

// EVOCACIONES (�XITO / FRACASO)
static float costoMaxEvoExitoABB = 0.0f;
static int totalEvoExitoABB = 0;
static float costoSumaEvoExitoABB = 0.0f;

static float costoMaxEvoFracasoABB = 0.0f;
static int totalEvoFracasoABB = 0;
static float costoSumaEvoFracasoABB = 0.0f;

// Rutinas internas para registro de m�tricas
static void registrarCostoAltaABB(float costoTotal) {
    totalAltasABB++;
    costoSumaAltaABB += costoTotal;
    if (costoTotal > costoMaxAltaABB) {
        costoMaxAltaABB = costoTotal;
    }
}

static void registrarCostoBajaABB(float costoTotal) {
    totalBajasABB++;
    costoSumaBajaABB += costoTotal;
    if (costoTotal > costoMaxBajaABB) {
        costoMaxBajaABB = costoTotal;
    }
}

static void registrarCostoEvocacionABB(float costoTotal, int exito) {
    if (exito) {
        totalEvoExitoABB++;
        costoSumaEvoExitoABB += costoTotal;
        if (costoTotal > costoMaxEvoExitoABB) {
            costoMaxEvoExitoABB = costoTotal;
        }
    } else {
        totalEvoFracasoABB++;
        costoSumaEvoFracasoABB += costoTotal;
        if (costoTotal > costoMaxEvoFracasoABB) {
            costoMaxEvoFracasoABB = costoTotal;
        }
    }
}

// Funciones selectoras (Getters) para informe final
static float getMediaAltaABB() {
    return totalAltasABB == 0 ? 0.0f : (costoSumaAltaABB / totalAltasABB);
}
static float getMaximoAltaABB() {
    return costoMaxAltaABB;
}

static float getMediaBajaABB() {
    return totalBajasABB == 0 ? 0.0f : (costoSumaBajaABB / totalBajasABB);
}
static float getMaximoBajaABB() {
    return costoMaxBajaABB;
}

static float getMediaEvoExitoABB() {
    return totalEvoExitoABB == 0 ? 0.0f : (costoSumaEvoExitoABB / totalEvoExitoABB);
}
static float getMaximoEvoExitoABB() {
    return costoMaxEvoExitoABB;
}

static float getMediaEvoFracasoABB() {
    return totalEvoFracasoABB == 0 ? 0.0f : (costoSumaEvoFracasoABB / totalEvoFracasoABB);
}
static float getMaximoEvoFracasoABB() {
    return costoMaxEvoFracasoABB;
}

// --- ESTRUCTURA DEL NODO Y DEL �RBOL ---
struct nodoABB {
    Elector dato;
    struct nodoABB *izq;
    struct nodoABB *der;
};

typedef struct nodoABB NodoABB;

typedef struct {
    NodoABB *raiz;
} ABB;

// --- INICIALIZAR ---
void abb_init(ABB *arbol) {
    arbol->raiz = NULL;
}

// --- AUXILIAR PARA VACIAR ---
static void liberar_nodos(NodoABB *r) {
    if (r != NULL) {
        liberar_nodos(r->izq);
        liberar_nodos(r->der);
        free(r);
    }
}

// --- VACIAR ---
void abb_vaciar(ABB *arbol) {
    liberar_nodos(arbol->raiz);
    arbol->raiz = NULL;
}

// --- LOCALIZAR ---
// Busca un DNI en el ABB.
// Devuelve 1 si lo encuentra (�xito) o 0 si no lo encuentra (fracaso).
// Retorna a trav�s de los punteros 'act' el nodo hallado (o NULL) y 'padre' el nodo padre.
int abb_localizar(ABB *arbol, int dni, NodoABB **act, NodoABB **padre, float *costo_cons) {
    *padre = NULL;
    *act = arbol->raiz;

    while (*act != NULL) {
        (*costo_cons) += 1.0f; // 1 punto de costo por celda/nodo examinado

        if (getDni(&((*act)->dato)) == dni) {
            return 1; // �xito: elemento encontrado
        }

        *padre = *act;
        if (dni < getDni(&((*act)->dato))) {
            *act = (*act)->izq;
        } else {
            *act = (*act)->der;
        }
    }
    return 0; // Fracaso: no encontrado
}

// --- ALTA ---
int abb_alta(ABB *arbol, Elector e, float *costo_cons, float *costo_mod) {
    NodoABB *act = NULL;
    NodoABB *padre = NULL;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    int existe = abb_localizar(arbol, getDni(&e), &act, &padre, costo_cons);

    if (existe) {
        return 0; // Clave duplicada (no se admiten DNI repetidos)
    }

    NodoABB *nuevo = (NodoABB *)malloc(sizeof(NodoABB));
    nuevo->dato = e;
    nuevo->izq = NULL;
    nuevo->der = NULL;

    if (padre == NULL) {
        arbol->raiz = nuevo;
    } else if (getDni(&e) < getDni(&(padre->dato))) {
        padre->izq = nuevo;
    } else {
        padre->der = nuevo;
    }

    (*costo_mod) += 0.5f; // Costo de 0.5 por modificaci�n de puntero

    // Registro del costo total de la operaci�n
    registrarCostoAltaABB(*costo_cons + *costo_mod);

    return 1;
}

// --- BAJA ---
int abb_baja(ABB *arbol, Elector e, float *costo_cons, float *costo_mod, int (*comp_fn)(Elector*, Elector*)) {
    NodoABB *act = NULL;
    NodoABB *padre = NULL;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    int existe = abb_localizar(arbol, getDni(&e), &act, &padre, costo_cons);

    if (existe) {
        // Confirmaci�n de la baja comparando la nupla completa por c�digo
        if (comp_fn(&(act->dato), &e)) {

            // Caso 1: El nodo no tiene hijo izquierdo
            if (act->izq == NULL) {
                if (padre == NULL) {
                    arbol->raiz = act->der;
                } else if (padre->izq == act) {
                    padre->izq = act->der;
                } else {
                    padre->der = act->der;
                }
                (*costo_mod) += 0.5f; // Modificaci�n de puntero
                free(act);
            }
            // Caso 2: El nodo no tiene hijo derecho
            else if (act->der == NULL) {
                if (padre == NULL) {
                    arbol->raiz = act->izq;
                } else if (padre->izq == act) {
                    padre->izq = act->izq;
                } else {
                    padre->der = act->izq;
                }
                (*costo_mod) += 0.5f; // Modificaci�n de puntero
                free(act);
            }
            // Caso 3: El nodo tiene 2 hijos -> Reemplazo por el Menor de los Mayores
            else {
                NodoABB *p_rem = act;
                NodoABB *rem = act->der;

                while (rem->izq != NULL) {
                    (*costo_cons) += 1.0f;
                    p_rem = rem;
                    rem = rem->izq;
                }
                (*costo_cons) += 1.0f; // Nodo evaluado en el corte del bucle

                act->dato = rem->dato; // Reemplazo con copia de datos
                (*costo_mod) += 1.0f;  // Costo adicional 1 por copia de datos

                // Desvincular el nodo de reemplazo
                if (p_rem == act) {
                    p_rem->der = rem->der;
                } else {
                    p_rem->izq = rem->der;
                }
                (*costo_mod) += 0.5f; // Modificaci�n de puntero
                free(rem);
            }

            // Registro del costo total de la operaci�n
            registrarCostoBajaABB(*costo_cons + *costo_mod);

            return 1; // Baja exitosa
        }
    }
    return 0; // Baja no efectuada
}

// --- EVOCACI�N ---
int abb_evocacion(ABB *arbol, int dni, Elector *res, float *costo_cons) {
    NodoABB *act = NULL;
    NodoABB *padre = NULL;
    *costo_cons = 0.0f;

    int existe = abb_localizar(arbol, dni, &act, &padre, costo_cons);

    if (existe) {
        if (res) *res = act->dato;

        // Registro de costo de la operaci�n (�xito)
        registrarCostoEvocacionABB(*costo_cons, 1);
        return 1;
    }

    // Registro de costo de la operaci�n (fracaso)
    registrarCostoEvocacionABB(*costo_cons, 0);
    return 0;
}

// --- AUXILIAR BARRIDO PREORDEN ---
static void preorden_recursivo(NodoABB *r, void (*imprimir_fn)(Elector*)) {
    if (r == NULL) return;

    printf("\n[NODO DNI: %d]\n", getDni(&(r->dato)));
    imprimir_fn(&(r->dato));

    if (r->izq != NULL) {
        printf("  -> Hijo Izquierdo DNI: %d\n", getDni(&(r->izq->dato)));
    } else {
        printf("  -> Hijo Izquierdo: No tiene\n");
    }

    if (r->der != NULL) {
        printf("  -> Hijo Derecho DNI: %d\n", getDni(&(r->der->dato)));
    } else {
        printf("  -> Hijo Derecho: No tiene\n");
    }

    preorden_recursivo(r->izq, imprimir_fn);
    preorden_recursivo(r->der, imprimir_fn);
}

// --- MOSTRAR (PREORDEN CON HIJOS) ---
void abb_mostrar(ABB *arbol, void (*imprimir_fn)(Elector*)) {
    printf("\n=== ARBOL BINARIO DE BUSQUEDA (ABB) - PREORDEN ===\n");
    if (arbol->raiz == NULL) {
        printf("El �rbol est� vac�o.\n");
    } else {
        preorden_recursivo(arbol->raiz, imprimir_fn);
    }
}

#endif
