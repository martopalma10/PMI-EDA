#ifndef LSOBB_H
#define LSOBB_H

#include "elector.h"

#define MAX_LSO 2500  //Se estiman 2000 pero no dice 2000 estricto

typedef struct {
    Elector datos[MAX_LSO];
    int cant;
} LSOBB;


// ==========================================
// VARIABLES Y M�TRICAS DE COMPARACI�N (GLOBALES)
// ==========================================

// ALTA
static float maximoAltaSOBB = 0.0f;
static int cantidadAltaSOBB = 0;
static float acumuladoAltaSOBB = 0.0f;

// BAJA
static float maximoBajaSOBB = 0.0f;
static int cantidadBajaSOBB = 0;
static float acumuladoBajaSOBB = 0.0f;

// EVOCACION EXITOSA Y FRACASO
static float maximoEvoExitoSOBB = 0.0f;
static int cantidadEvoExitoSOBB = 0;
static float acumuladoEvoExitoSOBB = 0.0f;

static float maximoEvoFracasoSOBB = 0.0f;
static int cantidadEvoFracasoSOBB = 0;
static float acumuladoEvoFracasoSOBB = 0.0f;

// Funciones auxiliares de actualizaci�n de m�tricas
static void actualizarMedicionesAltaListaSOBB(float costoOperacion) {
    cantidadAltaSOBB++;
    acumuladoAltaSOBB += costoOperacion;
    if (costoOperacion > maximoAltaSOBB) maximoAltaSOBB = costoOperacion;
}

static void actualizarMedicionesBajaListaSOBB(float costoOperacion) {
    cantidadBajaSOBB++;
    acumuladoBajaSOBB += costoOperacion;
    if (costoOperacion > maximoBajaSOBB) maximoBajaSOBB = costoOperacion;
}

static void actualizarMedicionesEvocacionListaSOBB(float costoOperacion, int exito) {
    if (exito) {
        cantidadEvoExitoSOBB++;
        acumuladoEvoExitoSOBB += costoOperacion;
        if (costoOperacion > maximoEvoExitoSOBB) maximoEvoExitoSOBB = costoOperacion;
    } else {
        cantidadEvoFracasoSOBB++;
        acumuladoEvoFracasoSOBB += costoOperacion;
        if (costoOperacion > maximoEvoFracasoSOBB) maximoEvoFracasoSOBB = costoOperacion;
    }
}

// Getters de m�tricas para la tabla final
static float getMediaAltaListaSOBB() { return cantidadAltaSOBB == 0 ? 0.0f : (acumuladoAltaSOBB / cantidadAltaSOBB); }
static float getMaximoAltaListaSOBB() { return maximoAltaSOBB; }

static float getMediaBajaListaSOBB() { return cantidadBajaSOBB == 0 ? 0.0f : (acumuladoBajaSOBB / cantidadBajaSOBB); }
static float getMaximoBajaListaSOBB() { return maximoBajaSOBB; }

static float getMediaEvoExitoListaSOBB() { return cantidadEvoExitoSOBB == 0 ? 0.0f : (acumuladoEvoExitoSOBB / cantidadEvoExitoSOBB); }
static float getMaximoEvoExitoListaSOBB() { return maximoEvoExitoSOBB; }

static float getMediaEvoFracasoListaSOBB() { return cantidadEvoFracasoSOBB == 0 ? 0.0f : (acumuladoEvoFracasoSOBB / cantidadEvoFracasoSOBB); }
static float getMaximoEvoFracasoListaSOBB() { return maximoEvoFracasoSOBB; }



// --- INICIALIZAR ---
void lsobb_init(LSOBB *l) {
    l->cant = 0;
}

// --- VACIAR ---
void lsobb_vaciar(LSOBB *l) {
    l->cant = 0;
}

// --- LOCALIZAR ---
// B�squeda binaria (Bisecci�n con l�mites inclusivos).
// Devuelve 1 si encuentra el DNI (�xito) y guarda en 'pos' su �ndice.
// Devuelve 0 si no lo encuentra (fracaso) y guarda en 'pos' el �ndice de inserci�n.
int lsobb_localizar(LSOBB *l, int dni, int *pos, float *costo_cons) {
    int vectorMarca[MAX_LSO] = {0};
    int li = 0, ls = l->cant - 1;
    int testigo;
    *costo_cons = 0;

    if(l->cant == 0){
        *pos = 0;
        return 0;
    }

    while (li < ls) {

        testigo = (li + ls) / 2;
        if(vectorMarca[testigo] != 1){
            *costo_cons = *costo_cons + 1;
            vectorMarca[testigo] = 1;
        }

        if (dni <= getDni(&(l->datos[testigo]))){
            ls = testigo;
        }else{
            li = testigo + 1;
        }
    }

    if (vectorMarca[li] != 1){
        *costo_cons= *costo_cons +1;
        vectorMarca [li] = 1;
    }
    if (dni == getDni(&(l->datos[testigo]))){
        *pos = testigo;
        return 1;
    }else {
        if (dni > getDni(&(l->datos[testigo]))){
            *pos = li + 1;
        }else{
            *pos = li;
        }
        return 0;
    }
}

// --- ALTA ---
int lsobb_alta(LSOBB *l, Elector e, float *costo_cons, float *costo_mod) {
    int pos, i;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    if (l->cant >= MAX_LSO) {
        return 0; // Lista llena
    }

    int existe = lsobb_localizar(l, getDni(&e), &pos, costo_cons);

    if (existe) {
        return 0; // Ya existe la clave (no se admiten duplicados)
    }

    // Corrimiento de elementos a la derecha para generar el espacio
    for (i = l->cant; i > pos; i--) {
        l->datos[i] = l->datos[i - 1];
        (*costo_mod) += 1.0f; // Cada corrimiento suma 1 de costo
    }

    l->datos[pos] = e;
    l->cant++;

    // Actualizaci�n autom�tica de m�tricas
    actualizarMedicionesAltaListaSOBB(*costo_cons + *costo_mod);

    return 1;
}

// --- BAJA ---
int lsobb_baja(LSOBB *l, Elector e, float *costo_cons, float *costo_mod, int (*comp_fn)(Elector*, Elector*)) {
    int pos, i;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    int existe = lsobb_localizar(l, getDni(&e), &pos, costo_cons);

    if (existe) {
        // Confirmaci�n de la baja por toda la nupla
        if (comp_fn(&(l->datos[pos]), &e)) {
            // Corrimiento de elementos a la izquierda
            for (i = pos; i < l->cant - 1; i++) {
                l->datos[i] = l->datos[i + 1];
                (*costo_mod) += 1.0f; // Cada corrimiento suma 1 de costo
            }
            l->cant--;

            // Actualizaci�n autom�tica de m�tricas
            actualizarMedicionesBajaListaSOBB(*costo_cons + *costo_mod);

            return 1;
        }
    }
    return 0;
}

// --- EVOCACI�N ---
int lsobb_evocacion(LSOBB *l, int dni, Elector *res, float *costo_cons) {
    int pos;
    *costo_cons = 0.0f;

    int existe = lsobb_localizar(l, dni, &pos, costo_cons);

    if (existe) {
        if (res) *res = l->datos[pos];

        // Actualizaci�n autom�tica de m�tricas (�xito)
        actualizarMedicionesEvocacionListaSOBB(*costo_cons, 1);
        return 1;
    }

    // Actualizaci�n autom�tica de m�tricas (fracaso)
    actualizarMedicionesEvocacionListaSOBB(*costo_cons, 0);
    return 0;
}

// --- MOSTRAR ---
void lsobb_mostrar(LSOBB *l, void (*imprimir_fn)(Elector*)) {
    int i;
    printf("\n=== LISTA SECUENCIAL ORDENADA (LSOBB) ===\n");
    for (i = 0; i < l->cant; i++) {
        imprimir_fn(&(l->datos[i]));
    }
}

#endif
