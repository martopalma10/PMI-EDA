/*
 * =====================================================================================
 * PRACTICO DE MAQUINA 1 - ESTRUCTURAS DE DATOS Y ALGORITMOS I (UNSL)
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "elector.h"
#include "lvo.h"
#include "lsobb.h"
#include "abb.h"

// -------------------------------------------------------------------------------------
// VARIABLES GLOBALES DE M�TRICAS (Definidas en los TDA correspondientes)[cite: 7]
// -------------------------------------------------------------------------------------
extern float costoSuma_LVO_cons;
extern float costoSuma_LVO_mod;
extern float costoSuma_LSO_cons;
extern float costoSuma_LSO_mod;
extern float costoSuma_ABB_cons;
extern float costoSuma_ABB_mod;

// --- FUNCIONES AUXILIARES REQUERIDAS ---[cite: 6]

static void trim_newline(char *str) {
    size_t len = strlen(str);
    while (len > 0 && (str[len - 1] == '\n' || str[len - 1] == '\r')) {
        str[len - 1] = '\0';
        len--;
    }
}

static int comparar_cadenas_ci(const char *s1, const char *s2) {
    while (*s1 && *s2) {
        char c1 = (char)tolower((unsigned char)*s1);
        char c2 = (char)tolower((unsigned char)*s2);
        if (c1 != c2) return c1 - c2;
        s1++;
        s2++;
    }
    return (char)tolower((unsigned char)*s1) - (char)tolower((unsigned char)*s2);
}

static int comparar_electores(Elector *e1, Elector *e2) {
    char *nom1 = (char*)getNombreApellido(e1);
    char *nom2 = (char*)getNombreApellido(e2);
    char *dom1 = (char*)getDomicilio(e1);
    char *dom2 = (char*)getDomicilio(e2);

    int coincide = 1;

    if (getDni(e1) != getDni(e2)) coincide = 0;
    else if (comparar_cadenas_ci(nom1, nom2) != 0) coincide = 0;
    else if (comparar_cadenas_ci(dom1, dom2) != 0) coincide = 0;
    else if (getCodPostal(e1) != getCodPostal(e2)) coincide = 0;
    else if (getMesa(e1) != getMesa(e2)) coincide = 0;
    else if (getCircuito(e1) != getCircuito(e2)) coincide = 0;

    return coincide;
}

static void mostrar_elector(Elector *e) {
    char *nom = (char*)getNombreApellido(e);
    char *dom = (char*)getDomicilio(e);

    printf("DNI: %ld | Nombre: %s | Domicilio: %s | CP: %d | Mesa: %d | Circuito: %d\n",
           getDni(e), nom, dom, getCodPostal(e), getMesa(e), getCircuito(e));
}

void ejecutar_operaciones_desde_archivo(LVO *lvo, LSOBB *lso, ABB *abb) {
    FILE *f = fopen("Operaciones_Padron.txt", "r");
    char linea[200];

    if (!f) {
        printf("Error: No se pudo abrir el archivo 'Operaciones_Padron.txt'.\n");
        return;
    }

    lvo_vaciar(lvo);[cite: 6]
    lsobb_vaciar(lso);[cite: 6]
    abb_vaciar(abb);[cite: 6]

    // Reiniciar los acumuladores globales antes de empezar la carga[cite: 7]
    costoSuma_LVO_cons = 0; costoSuma_LVO_mod = 0;
    costoSuma_LSO_cons = 0; costoSuma_LSO_mod = 0;
    costoSuma_ABB_cons = 0; costoSuma_ABB_mod = 0;

    while (fgets(linea, sizeof(linea), f)) {
        int op;
        trim_newline(linea);[cite: 6]
        if (strlen(linea) == 0) continue;

        op = atoi(linea);[cite: 6]
        if (op == 1 || op == 2) {
            Elector e;
            long dni;
            char nom[MAX_NOMBRE];
            char dom[MAX_DOMICILIO];
            int cp, mesa, circ;

            if (!fgets(linea, sizeof(linea), f)) break;
            dni = atol(linea);[cite: 6]

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);[cite: 6]
            strncpy(nom, linea, MAX_NOMBRE - 1);[cite: 6]
            nom[MAX_NOMBRE - 1] = '\0';[cite: 6]

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);[cite: 6]
            strncpy(dom, linea, MAX_DOMICILIO - 1);[cite: 6]
            dom[MAX_DOMICILIO - 1] = '\0';[cite: 6]

            if (!fgets(linea, sizeof(linea), f)) break;
            cp = atoi(linea);[cite: 6]

            if (!fgets(linea, sizeof(linea), f)) break;
            mesa = atoi(linea);[cite: 6]

            if (!fgets(linea, sizeof(linea), f)) break;
            circ = atoi(linea);[cite: 6]

            setDni(&e, dni);[cite: 6]
            setNombreApellido(&e, nom);[cite: 6]
            setDomicilio(&e, dom);[cite: 6]
            setCodPostal(&e, cp);[cite: 6]
            setMesa(&e, mesa);[cite: 6]
            setCircuito(&e, circ);[cite: 6]

            if (op == 1) {
                // Las firmas ya no requieren recibir variables de costos locales[cite: 7]
                lvo_alta(lvo, e);
                lsobb_alta(lso, e);
                abb_alta(abb, e);
            } else {
                lvo_baja(lvo, e, comparar_electores);
                lsobb_baja(lso, e, comparar_electores);
                abb_baja(abb, e, comparar_electores);
            }
        } else if (op == 3) {
            long dni;
            Elector res;
            if (!fgets(linea, sizeof(linea), f)) break;
            dni = atol(linea);[cite: 6]

            // Evocaci�n sin enviar punteros de costos[cite: 7]
            lvo_evocacion(lvo, dni, &res);
            lsobb_evocacion(lso, dni, &res);
            abb_evocacion(abb, dni, &res);
        }
    }

    fclose(f);[cite: 6]

    // Impresi�n con las m�tricas globales actualizadas[cite: 7]
    printf("\n=====================================================================\n");
    printf("                RESULTADOS DE LA COMPARACION DE COSTOS               \n");
    printf("=====================================================================\n");
    printf("%-10s | %-18s | %-18s | %-12s\n", "Estructura", "Costo Consultas", "Costo Modificac.", "Costo Total");
    printf("---------------------------------------------------------------------\n");
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "LVO", costoSuma_LVO_cons, costoSuma_LVO_mod, costoSuma_LVO_cons + costoSuma_LVO_mod);
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "LSOBB", costoSuma_LSO_cons, costoSuma_LSO_mod, costoSuma_LSO_cons + costoSuma_LSO_mod);
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "ABB", costoSuma_ABB_cons, costoSuma_ABB_mod, costoSuma_ABB_cons + costoSuma_ABB_mod);
    printf("=====================================================================\n");
}

int main() {
    LVO lvo;[cite: 6]
    LSOBB lso;[cite: 6]
    ABB abb;[cite: 6]
    int opcion = -1, subopcion = 0;[cite: 6]

    lvo_init(&lvo);[cite: 6]
    lsobb_init(&lso);[cite: 6]
    abb_init(&abb);[cite: 6]

    do {
        printf("\n======================================\n");
        printf("    PADRON ELECTORAL DE SAN LUIS      \n");
        printf("======================================\n");
        printf("1. Comparacion de Estructuras\n");
        printf("2. Mostrar Estructura\n");
        printf("0. Salir\n");
        printf("Seleccione una opcion: ");
        if (scanf("%d", &opcion) != 1) break;[cite: 6]

        switch (opcion) {
            case 1:
                ejecutar_operaciones_desde_archivo(&lvo, &lso, &abb);[cite: 6]
                break;
            case 2:
                printf("\n--- MOSTRAR ESTRUCTURA ---\n");
                printf("1. Mostrar Lista Vinculada Ordenada (LVO)\n");
                printf("2. Mostrar Lista Secuencial Ordenada (LSOBB)\n");
                printf("3. Mostrar Arbol Binario de Busqueda (ABB Preorden)\n");
                printf("Seleccione la estructura a mostrar: ");
                scanf("%d", &subopcion);[cite: 6]

                if (subopcion == 1) lvo_mostrar(&lvo, mostrar_elector);[cite: 6]
                else if (subopcion == 2) lsobb_mostrar(&lso, mostrar_elector);[cite: 6]
                else if (subopcion == 3) abb_mostrar_preorden(&abb, mostrar_elector);[cite: 6]
                else printf("Opci�n inv�lida.\n");
                break;
            case 0:
                printf("Saliendo del programa...\n");
                break;
            default:
                printf("Opci�n no v�lida.\n");
        }
    } while (opcion != 0);[cite: 6]

    return 0;
}
