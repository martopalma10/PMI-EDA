#ifndef LVO_H
#define LVO_H

#include "elector.h"

#define MAS_INFINITO 999999999

// ==========================================
// REGISTRO Y ESTAD�STICAS DE COSTOS (GLOBALES)
// ==========================================

float costoSuma_LVO_cons = 0;
float costoSuma_LVO_mod = 0;

// ALTAS
static float costoMaxAltaLVO = 0.0f;
static int totalAltasLVO = 0;
static float costoSumaAltaLVO = 0.0f;

// BAJAS
static float costoMaxBajaLVO = 0.0f;
static int totalBajasLVO = 0;
static float costoSumaBajaLVO = 0.0f;

// EVOCACIONES (�XITO / FRACASO)
static float costoMaxEvoExitoLVO = 0.0f;
static int totalEvoExitoLVO = 0;
static float costoSumaEvoExitoLVO = 0.0f;

static float costoMaxEvoFracasoLVO = 0.0f;
static int totalEvoFracasoLVO = 0;
static float costoSumaEvoFracasoLVO = 0.0f;

// Rutinas internas para registro de m�tricas
static void registrarCostoAltaLVO(float costoTotal) {
    totalAltasLVO++;
    costoSumaAltaLVO += costoTotal;
    if (costoTotal > costoMaxAltaLVO) {
        costoMaxAltaLVO = costoTotal;
    }
}

static void registrarCostoBajaLVO(float costoTotal) {
    totalBajasLVO++;
    costoSumaBajaLVO += costoTotal;
    if (costoTotal > costoMaxBajaLVO) {
        costoMaxBajaLVO = costoTotal;
    }
}

static void registrarCostoEvocacionLVO(float costoTotal, int exito) {
    if (exito) {
        totalEvoExitoLVO++;
        costoSumaEvoExitoLVO += costoTotal;
        if (costoTotal > costoMaxEvoExitoLVO) {
            costoMaxEvoExitoLVO = costoTotal;
        }
    } else {
        totalEvoFracasoLVO++;
        costoSumaEvoFracasoLVO += costoTotal;
        if (costoTotal > costoMaxEvoFracasoLVO) {
            costoMaxEvoFracasoLVO = costoTotal;
        }
    }
}

// Funciones selectoras (Getters) para informe final
static float getMediaAltaListaVO() {
    return totalAltasLVO == 0 ? 0.0f : (costoSumaAltaLVO / totalAltasLVO);
}
static float getMaximoAltaListaVO() {
    return costoMaxAltaLVO;
}

static float getMediaBajaListaVO() {
    return totalBajasLVO == 0 ? 0.0f : (costoSumaBajaLVO / totalBajasLVO);
}
static float getMaximoBajaListaVO() {
    return costoMaxBajaLVO;
}

static float getMediaEvoExitoListaVO() {
    return totalEvoExitoLVO == 0 ? 0.0f : (costoSumaEvoExitoLVO / totalEvoExitoLVO);
}
static float getMaximoEvoExitoListaVO() {
    return costoMaxEvoExitoLVO;
}

static float getMediaEvoFracasoListaVO() {
    return totalEvoFracasoLVO == 0 ? 0.0f : (costoSumaEvoFracasoLVO / totalEvoFracasoLVO);
}
static float getMaximoEvoFracasoListaVO() {
    return costoMaxEvoFracasoLVO;
}

struct nodo {
    Elector dato;
    struct nodo *sig;
};

typedef struct nodo NodoLVO;

typedef struct {
    NodoLVO *head;
} LVO;

void lvo_init(LVO *l) {
    l->head = (NodoLVO *)malloc(sizeof(NodoLVO));
    setDni(&(l->head->dato), MAS_INFINITO);
    l->head->sig = NULL;
}

void lvo_vaciar(LVO *l) {
    NodoLVO *aux;
    NodoLVO *act = l->head;
    while (act != NULL) {
        aux = act;
        act = act->sig;
        free(aux);
    }
    lvo_init(l);
}

int lvo_localizar(LVO *l, long dni, NodoLVO **ant, NodoLVO **act, float *costo_cons) {
    *ant = NULL;
    *act = l->head;

    while (getDni(&((*act)->dato)) < dni) {
        (*costo_cons) += 1.0f;
        *ant = *act;
        *act = (*act)->sig;
    }
    (*costo_cons) += 1.0f; // Costo del nodo donde corta (coincide o supera)

    if (getDni(&((*act)->dato)) == dni && getDni(&((*act)->dato)) < MAS_INFINITO) {
        return 1; // �xito: elemento encontrado
    }
    return 0; // Fracaso: elemento no encontrado
}

int lvo_alta(LVO *l, Elector e, float *costo_cons, float *costo_mod) {
    NodoLVO *ant = NULL;
    NodoLVO *act = NULL;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    int existe = lvo_localizar(l, getDni(&e), &ant, &act, costo_cons);

    if (existe) {
        return 0; // Ya existe el DNI
    }

    NodoLVO *nuevo = (NodoLVO *)malloc(sizeof(NodoLVO));
    nuevo->dato = e;
    nuevo->sig = act;
    (*costo_mod) += 0.5f;

    if (ant == NULL) {
        l->head = nuevo;
    } else {
        ant->sig = nuevo;
    }
    (*costo_mod) += 0.5f;

    // Registro de costo total de la operaci�n (modificaci�n de punteros)
    registrarCostoAltaLVO(*costo_cons + *costo_mod);

    return 1;
}

int lvo_baja(LVO *l, Elector e, float *costo_cons, float *costo_mod, int (*comp_fn)(Elector*, Elector*)) {
    NodoLVO *ant = NULL;
    NodoLVO *act = NULL;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    int existe = lvo_localizar(l, getDni(&e), &ant, &act, costo_cons);

    if (existe) {
        if (comp_fn(&(act->dato), &e)) {
            if (ant == NULL) {
                l->head = act->sig;
            } else {
                ant->sig = act->sig;
            }
            (*costo_mod) += 0.5f;
            free(act);

            // Registro de costo total de la operaci�n
            registrarCostoBajaLVO(*costo_cons + *costo_mod);

            return 1;
        }
    }
    return 0;
}

int lvo_evocacion(LVO *l, long dni, Elector *res, float *costo_cons) {
    NodoLVO *ant = NULL;
    NodoLVO *act = NULL;
    *costo_cons = 0.0f;

    int existe = lvo_localizar(l, dni, &ant, &act, costo_cons);

    if (existe) {
        if (res) *res = act->dato;

        // Registro de costo de la operaci�n (�xito)
        registrarCostoEvocacionLVO(*costo_cons, 1);
        return 1;
    }

    // Registro de costo de la operaci�n (fracaso)
    registrarCostoEvocacionLVO(*costo_cons, 0);
    return 0;
}

void lvo_mostrar(LVO *l, void (*imprimir_fn)(Elector*)) {
    NodoLVO *act = l->head;
    printf("\n=== LISTA VINCULADA ORDENADA (LVO) ===\n");
    while (act != NULL && getDni(&(act->dato)) != MAS_INFINITO) {
        imprimir_fn(&(act->dato));
        act = act->sig;
    }
}

#endif
