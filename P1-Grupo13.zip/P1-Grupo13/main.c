/*
 * =====================================================================================
 * PRACTICO DE MAQUINA 1 - ESTRUCTURAS DE DATOS Y ALGORITMOS I (UNSL)
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "elector.H"
#include "lvo.h"
#include "lsobb.h"
#include "abb.h"


// --- FUNCIONES AUXILIARES REQUERIDAS ---[cite: 6]

static void trim_newline(char *str) {
    size_t len = strlen(str);
    while (len > 0 && (str[len - 1] == '\n' || str[len - 1] == '\r')) {
        str[len - 1] = '\0';
        len--;
    }
}

static int comparar_cadenas_ci(const char *s1, const char *s2) {
    while (*s1 && *s2) {
        char c1 = (char)tolower((unsigned char)*s1);
        char c2 = (char)tolower((unsigned char)*s2);
        if (c1 != c2) return c1 - c2;
        s1++;
        s2++;
    }
    return (char)tolower((unsigned char)*s1) - (char)tolower((unsigned char)*s2);
}

static int comparar_electores(Elector *e1, Elector *e2) {
    char *nom1 = (char*)getNombreApellido(e1);
    char *nom2 = (char*)getNombreApellido(e2);
    char *dom1 = (char*)getDomicilio(e1);
    char *dom2 = (char*)getDomicilio(e2);

    int coincide = 1;

    if (getDni(e1) != getDni(e2)) coincide = 0;
    else if (comparar_cadenas_ci(nom1, nom2) != 0) coincide = 0;
    else if (comparar_cadenas_ci(dom1, dom2) != 0) coincide = 0;
    else if (getCodPostal(e1) != getCodPostal(e2)) coincide = 0;
    else if (getMesa(e1) != getMesa(e2)) coincide = 0;
    else if (getCircuito(e1) != getCircuito(e2)) coincide = 0;

    free(nom1); free(nom2); free(dom1); free(dom2);
    return coincide;
}

static void mostrar_elector(Elector *e) {
    char *nom = (char*)getNombreApellido(e);
    char *dom = (char*)getDomicilio(e);

    printf("DNI: %ld | Nombre: %s | Domicilio: %s | CP: %d | Mesa: %d | Circuito: %d\n",
           getDni(e), nom, dom, getCodPostal(e), getMesa(e), getCircuito(e));
           free(nom); free(dom);
}

void ejecutar_operaciones_desde_archivo(LVO *lvo, LSOBB *lso, ABB *abb) {
    FILE *f = fopen("Operaciones_Padron.txt", "r");
    char linea[200];

    if (!f) {
        printf("Error: No se pudo abrir el archivo 'Operaciones_Padron.txt'.\n");
        return;
    }

    lvo_vaciar(lvo);
    lsobb_vaciar(lso);
    abb_vaciar(abb);

    // Reiniciar los acumuladores globales antes de empezar la carga[cite: 7]
    costoSuma_LVO_cons = 0; costoSuma_LVO_mod = 0;
    costoSuma_LSO_cons = 0; costoSuma_LSO_mod = 0;
    costoSuma_ABB_cons = 0; costoSuma_ABB_mod = 0;

    while (fgets(linea, sizeof(linea), f)) {
        int op;
        trim_newline(linea);
        if (strlen(linea) == 0) continue;

        op = atoi(linea);
        if (op == 1 || op == 2) {
            Elector e;
            long dni;
            char nom[MAX_NOMBRE];
            char dom[MAX_DOMICILIO];
            int cp, mesa, circ;

            if (!fgets(linea, sizeof(linea), f)) break;
            dni = atol(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);
            strncpy(nom, linea, MAX_NOMBRE - 1);
            nom[MAX_NOMBRE - 1] = '\0';

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);
            strncpy(dom, linea, MAX_DOMICILIO - 1);
            dom[MAX_DOMICILIO - 1] = '\0';

            if (!fgets(linea, sizeof(linea), f)) break;
            cp = atoi(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            mesa = atoi(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            circ = atoi(linea);

            setDni(&e, dni);
            setNombreApellido(&e, nom);
            setDomicilio(&e, dom);
            setCodPostal(&e, cp);
            setMesa(&e, mesa);
            setCircuito(&e, circ);

            if (op == 1) {
    float cc=0, cm=0;
        lvo_alta(lvo, e, &cc, &cm); costoSuma_LVO_cons+=cc; costoSuma_LVO_mod+=cm;
        lsobb_alta(lso, e, &cc, &cm); costoSuma_LSO_cons+=cc; costoSuma_LSO_mod+=cm;
        abb_alta(abb, e, &cc, &cm); costoSuma_ABB_cons+=cc; costoSuma_ABB_mod+=cm;
        } else
        {
    float cc=0, cm=0;
        lvo_baja(lvo, e, &cc, &cm, comparar_electores); costoSuma_LVO_cons+=cc; costoSuma_LVO_mod+=cm;
        lsobb_baja(lso, e, &cc, &cm, comparar_electores); costoSuma_LSO_cons+=cc; costoSuma_LSO_mod+=cm;
        abb_baja(abb, e, &cc, &cm, comparar_electores); costoSuma_ABB_cons+=cc; costoSuma_ABB_mod+=cm;
        }
        } else if (op == 3) {
            long dni;
            Elector res;
            if (!fgets(linea, sizeof(linea), f)) break;
            dni = atol(linea);

            // Evocaci�n sin enviar punteros de costos
        float cc=0;
            lvo_evocacion(lvo, dni, &res, &cc); costoSuma_LVO_cons+=cc;
            lsobb_evocacion(lso, dni, &res, &cc); costoSuma_LSO_cons+=cc;
            abb_evocacion(abb, dni, &res, &cc); costoSuma_ABB_cons+=cc;
        }
    }

    fclose(f);

    // Impresi�n con las m�tricas globales actualizadas
    // Impresi�n con un dise�o renovado (por bloques de operaci�n)
    printf("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
    printf("+               REPORTE DETALLADO DE COSTOS POR OPERACION              +\n");
    printf("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

    // --- BLOQUE: ALTA ---
    printf("\n>>> OPERACION: ALTA (Total de operaciones: %d)\n", totalAltasLVO); // Usamos LVO como referencia para el total, asumiendo que es el mismo para todas[cite: 4, 7]
    printf("========================================================================\n");
    printf("| %-15s | %-20s | %-20s |\n", "ESTRUCTURA", "COSTO MAXIMO", "COSTO PROMEDIO");
    printf("|-----------------|----------------------|----------------------|\n");
    printf("| %-15s | %20.2f | %20.2f |\n", "LVO", getMaximoAltaListaVO(), getMediaAltaListaVO());
    printf("| %-15s | %20.2f | %20.2f |\n", "LSOBB", getMaximoAltaListaSOBB(), getMediaAltaListaSOBB());
    printf("| %-15s | %20.2f | %20.2f |\n", "ABB", getMaximoAltaABB(), getMediaAltaABB());
    printf("========================================================================\n");

    // --- BLOQUE: BAJA ---
    printf("\n>>> OPERACION: BAJA (Total de operaciones: %d)\n", totalBajasLVO);
    printf("========================================================================\n");
    printf("| %-15s | %-20s | %-20s |\n", "ESTRUCTURA", "COSTO MAXIMO", "COSTO PROMEDIO");
    printf("|-----------------|----------------------|----------------------|\n");
    printf("| %-15s | %20.2f | %20.2f |\n", "LVO", getMaximoBajaListaVO(), getMediaBajaListaVO());
    printf("| %-15s | %20.2f | %20.2f |\n", "LSOBB", getMaximoBajaListaSOBB(), getMediaBajaListaSOBB());
    printf("| %-15s | %20.2f | %20.2f |\n", "ABB", getMaximoBajaABB(), getMediaBajaABB());
    printf("========================================================================\n");

    // --- BLOQUE: EVOCACION EXITO ---
    printf("\n>>> OPERACION: EVOCACION (EXITO) (Total de operaciones: %d)\n", totalEvoExitoLVO);
    printf("========================================================================\n");
    printf("| %-15s | %-20s | %-20s |\n", "ESTRUCTURA", "COSTO MAXIMO", "COSTO PROMEDIO");
    printf("|-----------------|----------------------|----------------------|\n");
    printf("| %-15s | %20.2f | %20.2f |\n", "LVO", getMaximoEvoExitoListaVO(), getMediaEvoExitoListaVO());
    printf("| %-15s | %20.2f | %20.2f |\n", "LSOBB", getMaximoEvoExitoListaSOBB(), getMediaEvoExitoListaSOBB());
    printf("| %-15s | %20.2f | %20.2f |\n", "ABB", getMaximoEvoExitoABB(), getMediaEvoExitoABB());
    printf("========================================================================\n");

    // --- BLOQUE: EVOCACION FRACASO ---
    printf("\n>>> OPERACION: EVOCACION (FRACASO) (Total de operaciones: %d)\n", totalEvoFracasoLVO);
    printf("========================================================================\n");
    printf("| %-15s | %-20s | %-20s |\n", "ESTRUCTURA", "COSTO MAXIMO", "COSTO PROMEDIO");
    printf("|-----------------|----------------------|----------------------|\n");
    printf("| %-15s | %20.2f | %20.2f |\n", "LVO", getMaximoEvoFracasoListaVO(), getMediaEvoFracasoListaVO());
    printf("| %-15s | %20.2f | %20.2f |\n", "LSOBB", getMaximoEvoFracasoListaSOBB(), getMediaEvoFracasoListaSOBB());
    printf("| %-15s | %20.2f | %20.2f |\n", "ABB", getMaximoEvoFracasoABB(), getMediaEvoFracasoABB());
    printf("========================================================================\n");
}

int main() {
    LVO lvo;
    LSOBB lso;
    ABB abb;
    int opcion = -1, subopcion = 0;
    lvo_init(&lvo);
    lsobb_init(&lso);
    abb_init(&abb);

    do {
        printf("\n======================================\n");
        printf("    PADRON ELECTORAL DE SAN LUIS      \n");
        printf("======================================\n");
        printf("1. Comparacion de Estructuras\n");
        printf("2. Mostrar Estructura\n");
        printf("0. Salir\n");
        printf("Seleccione una opcion: ");
        if (scanf("%d", &opcion) != 1) break;
        getchar();

        switch (opcion) {
            case 1:
                ejecutar_operaciones_desde_archivo(&lvo, &lso, &abb);
                break;
            case 2:
                printf("\n--- MOSTRAR ESTRUCTURA ---\n");
                printf("1. Mostrar Lista Vinculada Ordenada (LVO)\n");
                printf("2. Mostrar Lista Secuencial Ordenada (LSOBB)\n");
                printf("3. Mostrar Arbol Binario de Busqueda (ABB Preorden)\n");
                printf("Seleccione la estructura a mostrar: ");
                scanf("%d", &subopcion);

                if (subopcion == 1) lvo_mostrar(&lvo, mostrar_elector);
                else if (subopcion == 2) lsobb_mostrar(&lso, mostrar_elector);
                else if (subopcion == 3) abb_mostrar_preorden(&abb, mostrar_elector);
                else printf("Opci�n inv�lida.\n");
                break;
            case 0:
                printf("Saliendo del programa...\n");
                break;
            default:
                printf("Opci�n no v�lida.\n");
        }
    } while (opcion != 0);

    return 0;
}
