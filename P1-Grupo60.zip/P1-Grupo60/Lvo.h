#ifndef LVO_H
#define LVO_H

#include "elector.h"

typedef struct NodoLVO {
    Elector dato;
    struct NodoLVO *sig;
} NodoLVO;

typedef struct {
    NodoLVO *head;
} LVO;

static void lvo_init(LVO *l) {
    NodoLVO *inf = (NodoLVO *)malloc(sizeof(NodoLVO));
    inf->dato.dni = MAS_INFINITO;
    inf->sig = NULL;
    l->head = inf;
}

static void lvo_vaciar(LVO *l) {
    NodoLVO *act = l->head;
    while (act != NULL) {
        NodoLVO *sig = act->sig;
        free(act);
        act = sig;
    }
    lvo_init(l);
}

static int lvo_alta(LVO *l, Elector e, float *costo_cons, float *costo_mod) {
    NodoLVO *ant = NULL;
    NodoLVO *act = l->head;

    while (act->dato.dni < e.dni) {
        (*costo_cons) += 1.0f;
        ant = act;
        act = act->sig;
    }
    (*costo_cons) += 1.0f;

    if (act->dato.dni == e.dni) {
        return 0; // Ya existe el DNI
    }

    NodoLVO *nuevo = (NodoLVO *)malloc(sizeof(NodoLVO));
    nuevo->dato = e;
    nuevo->sig = act;     // Modificaci�n de puntero (0.5)
    (*costo_mod) += 0.5f;

    if (ant == NULL) {
        l->head = nuevo;  // Modificaci�n de puntero (0.5)
    } else {
        ant->sig = nuevo; // Modificaci�n de puntero (0.5)
    }
    (*costo_mod) += 0.5f;

    return 1;
}

static int lvo_baja(LVO *l, Elector e, float *costo_cons, float *costo_mod) {
    NodoLVO *ant = NULL;
    NodoLVO *act = l->head;

    while (act->dato.dni < e.dni) {
        (*costo_cons) += 1.0f;
        ant = act;
        act = act->sig;
    }
    (*costo_cons) += 1.0f;

    if (act->dato.dni == e.dni) {
        if (comparar_electores(act->dato, e)) {
            if (ant == NULL) {
                l->head = act->sig;
            } else {
                ant->sig = act->sig;
            }
            (*costo_mod) += 0.5f; // Modificaci�n de puntero
            free(act);
            return 1;
        }
    }
    return 0;
}

static int lvo_evocacion(LVO *l, long dni, Elector *res, float *costo_cons) {
    NodoLVO *act = l->head;
    while (act->dato.dni < dni) {
        (*costo_cons) += 1.0f;
        act = act->sig;
    }
    (*costo_cons) += 1.0f;

    if (act->dato.dni == dni) {
        if (res) *res = act->dato;
        return 1;
    }
    return 0;
}

static void lvo_mostrar(LVO *l) {
    NodoLVO *act = l->head;
    printf("\n=== MOSTRAR LISTA VINCULADA ORDENADA (LVO) ===\n");
    while (act != NULL && act->dato.dni != MAS_INFINITO) {
        mostrar_elector(act->dato);
        act = act->sig;
    }
}

#endif
