#ifndef LSOBB_H
#define LSOBB_H

#include "elector.h"

#define MAX_LSO 2000

typedef struct {
    Elector datos[MAX_LSO];
    int cant;
} LSOBB;

static void lsobb_init(LSOBB *l) {
    l->cant = 0;
}

static void lsobb_vaciar(LSOBB *l) {
    l->cant = 0;
}

static int busqueda_binaria(LSOBB *l, long dni, int *pos, float *costo_cons) {
    int li = 0, ls = l->cant - 1;
    int m = 0;

    while (li <= ls) {
        m = (li + ls) / 2;
        (*costo_cons) += 1.0f; // 1 celda consultada
        if (l->datos[m].dni == dni) {
            *pos = m;
            return 1;
        }
        if (dni < l->datos[m].dni) {
            ls = m - 1;
        } else {
            li = m + 1;
        }
    }
    *pos = li;
    return 0;
}

static int lsobb_alta(LSOBB *l, Elector e, float *costo_cons, float *costo_mod) {
    if (l->cant >= MAX_LSO) return 0;

    int pos;
    int i;
    if (busqueda_binaria(l, e.dni, &pos, costo_cons)) {
        return 0;
    }

    for (i = l->cant; i > pos; i--) {
        l->datos[i] = l->datos[i - 1];
        (*costo_mod) += 1.0f; // 1 corrimiento = costo 1
    }

    l->datos[pos] = e;
    l->cant++;
    return 1;
}

static int lsobb_baja(LSOBB *l, Elector e, float *costo_cons, float *costo_mod) {
    int pos;
    int i;
    if (busqueda_binaria(l, e.dni, &pos, costo_cons)) {
        if (comparar_electores(l->datos[pos], e)) {
            for (i = pos; i < l->cant - 1; i++) {
                l->datos[i] = l->datos[i + 1];
                (*costo_mod) += 1.0f; // 1 corrimiento = costo 1
            }
            l->cant--;
            return 1;
        }
    }
    return 0;
}

static int lsobb_evocacion(LSOBB *l, long dni, Elector *res, float *costo_cons) {
    int pos;
    if (busqueda_binaria(l, dni, &pos, costo_cons)) {
        if (res) *res = l->datos[pos];
        return 1;
    }
    return 0;
}

static void lsobb_mostrar(LSOBB *l) {
    printf("\n=== MOSTRAR LISTA SECUENCIAL ORDENADA (LSOBB) ===\n");
    int i;
    for (i = 0; i < l->cant; i++) {
        mostrar_elector(l->datos[i]);
    }
}

#endif
