#ifndef LSOBB_H
#define LSOBB_H

#include "elector.h"

#define MAX_LSO 2500  //Se estiman 2000 pero no dice 2000 estricto

typedef struct {
    Elector datos[MAX_LSO];
    int cant;
} LSOBB;

// --- INICIALIZAR ---
static void lsobb_init(LSOBB *l) {
    l->cant = 0;
}

// --- VACIAR ---
static void lsobb_vaciar(LSOBB *l) {
    l->cant = 0;
}

// --- LOCALIZAR ---
// B�squeda binaria (Bisecci�n con l�mites inclusivos).
// Devuelve 1 si encuentra el DNI (�xito) y guarda en 'pos' su �ndice.
// Devuelve 0 si no lo encuentra (fracaso) y guarda en 'pos' el �ndice de inserci�n.
static int lsobb_localizar(LSOBB *l, int dni, int *pos, float *costo_cons) {
    int vectorMarca[MAX_LSO] = {0};
    int li = 0, ls = l->cant - 1;
    int testigo;
    *costo_cons = 0;

    if(l->cant == 0){
        *pos = 0;
        return 0;
    }

    while (li < ls) {

        testigo = (li + ls) / 2;
        if(vectorMarca[testigo] != 1){
            *costo_cons = *costo_cons + 1;
            vectorMarca[testigo] = 1;
        }

        if (dni <= getDni(&(l->datos[testigo]))){
            ls = testigo;
        }else{
            li = testigo + 1;
        }
    }

    if (vectorMarca[li] != 1){
        *costo_cons= *costo_cons +1;
        vectorMarca [li] = 1;
    }
    if (dni == getDni(&(l->datos[testigo]))){
        *pos = testigo;
        return 1;
    }else {
        if (dni > getDni(&(l->datos[testigo]))){
            *pos = li + 1;
        }else{
            *pos = li;
        }
        return 0;
    }
}

// --- ALTA ---
static int lsobb_alta(LSOBB *l, Elector e, float *costo_cons, float *costo_mod) {
    int pos, i;

    if (l->cant >= MAX_LSO) {
        return 0; // Lista llena
    }

    int existe = lsobb_localizar(l, getDni(&e), &pos, costo_cons);

    if (existe) {
        return 0; // Ya existe la clave (no se admiten duplicados)
    }

    // Corrimiento de elementos a la derecha para generar el espacio
    for (i = l->cant; i > pos; i--) {
        l->datos[i] = l->datos[i - 1];
        (*costo_mod) += 1.0f; // Cada corrimiento suma 1 de costo
    }

    l->datos[pos] = e;
    l->cant++;
    return 1;
}

// --- BAJA ---
static int lsobb_baja(LSOBB *l, Elector e, float *costo_cons, float *costo_mod, int (*comp_fn)(Elector*, Elector*)) {
    int pos, i;

    int existe = lsobb_localizar(l, getDni(&e), &pos, costo_cons);

    if (existe) {
        // Confirmaci�n de la baja por toda la nupla
        if (comp_fn(&(l->datos[pos]), &e)) {
            // Corrimiento de elementos a la izquierda
            for (i = pos; i < l->cant - 1; i++) {
                l->datos[i] = l->datos[i + 1];
                (*costo_mod) += 1.0f; // Cada corrimiento suma 1 de costo
            }
            l->cant--;
            return 1;
        }
    }
    return 0;
}

// --- EVOCACI�N ---
static int lsobb_evocacion(LSOBB *l, int dni, Elector *res, float *costo_cons) {
    int pos;

    int existe = lsobb_localizar(l, dni, &pos, costo_cons);

    if (existe) {
        if (res) *res = l->datos[pos];
        return 1;
    }
    return 0;
}

// --- MOSTRAR ---
static void lsobb_mostrar(LSOBB *l, void (*imprimir_fn)(Elector*)) {
    int i;
    printf("\n=== LISTA SECUENCIAL ORDENADA (LSOBB) ===\n");
    for (i = 0; i < l->cant; i++) {
        imprimir_fn(&(l->datos[i]));
    }
}

#endif
