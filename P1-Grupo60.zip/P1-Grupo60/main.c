/*
 * =====================================================================================
 * PRACTICO DE MAQUINA 1 - ESTRUCTURAS DE DATOS Y ALGORITMOS I (UNSL)
 * GRUPO: XX
 * =====================================================================================
 * RESULTADOS Y CONCLUSIONES DEL ANALISIS DE COMPARACION DE ESTRUCTURAS:
 *
 * CONCLUSIONES GENERALES:
 * 1. Consultas (Evocaciones):
 *    - La LSOBB y el ABB son significativamente m�s eficientes que la LVO en consultas.
 *    - LSOBB realiza O(log N) accesos mediante la t�cnica de bisecci�n.
 *    - ABB logra accesos promedios de orden O(log N), dependiendo de la secuencia de altas.
 *    - LVO requiere en el peor escenario O(N) accesos por su b�squeda secuencial.
 *
 * 2. Altas y Bajas (Modificaciones):
 *    - LVO y ABB requieren costo de modificaci�n din�mico muy bajo (0.5 por actualizaci�n de puntero).
 *    - LSOBB sufre un alto costo en altas y bajas por el corrimiento contiguo de memoria (costo 1 por elemento).
 *
 * 3. Estructura Recomendada:
 *    - LSOBB es id�nea para entornos con alta tasa de consulta y escasas modificaciones.
 *    - ABB representa el mejor compromiso global cuando las tres operaciones son frecuentes.
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "elector.h"
#include "lvo.h"
#include "lsobb.h"
#include "abb.h"

void ejecutar_operaciones_desde_archivo(LVO *lvo, LSOBB *lso, ABB *abb) {
    FILE *f = fopen("Operaciones_Padron.txt", "r");
    if (!f) {
        printf("Error: No se pudo abrir el archivo 'Operaciones_Padron.txt'.\n");
        return;
    }

    lvo_vaciar(lvo);
    lsobb_vaciar(lso);
    abb_vaciar(abb);

    float c_cons_lvo = 0, c_mod_lvo = 0;
    float c_cons_lso = 0, c_mod_lso = 0;
    float c_cons_abb = 0, c_mod_abb = 0;

    char linea[200];
    while (fgets(linea, sizeof(linea), f)) {
        trim_newline(linea);
        if (strlen(linea) == 0) continue;

        int op = atoi(linea);
        Elector e;
        memset(&e, 0, sizeof(Elector));

        if (op == 1 || op == 2) {
            if (!fgets(linea, sizeof(linea), f)) break;
            e.dni = atol(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);
            strncpy(e.nombre, linea, MAX_NOMBRE - 1);

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);
            strncpy(e.domicilio, linea, MAX_DOMICILIO - 1);

            if (!fgets(linea, sizeof(linea), f)) break;
            e.cp = atoi(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            e.mesa = atoi(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            e.circuito = atoi(linea);

            if (op == 1) {
                lvo_alta(lvo, e, &c_cons_lvo, &c_mod_lvo);
                lsobb_alta(lso, e, &c_cons_lso, &c_mod_lso);
                abb_alta(abb, e, &c_cons_abb, &c_mod_abb);
            } else {
                lvo_baja(lvo, e, &c_cons_lvo, &c_mod_lvo);
                lsobb_baja(lso, e, &c_cons_lso, &c_mod_lso);
                abb_baja(abb, e, &c_cons_abb, &c_mod_abb);
            }
        } else if (op == 3) {
            if (!fgets(linea, sizeof(linea), f)) break;
            long dni = atol(linea);

            Elector res;
            lvo_evocacion(lvo, dni, &res, &c_cons_lvo);
            lsobb_evocacion(lso, dni, &res, &c_cons_lso);
            abb_evocacion(abb, dni, &res, &c_cons_abb);
        }
    }

    fclose(f);

    printf("\n=====================================================================\n");
    printf("                RESULTADOS DE LA COMPARACION DE COSTOS               \n");
    printf("=====================================================================\n");
    printf("%-10s | %-18s | %-18s | %-12s\n", "Estructura", "Costo Consultas", "Costo Modificac.", "Costo Total");
    printf("---------------------------------------------------------------------\n");
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "LVO", c_cons_lvo, c_mod_lvo, c_cons_lvo + c_mod_lvo);
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "LSOBB", c_cons_lso, c_mod_lso, c_cons_lso + c_mod_lso);
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "ABB", c_cons_abb, c_mod_abb, c_cons_abb + c_mod_abb);
    printf("=====================================================================\n");
}

int main() {
    LVO lvo;
    LSOBB lso;
    ABB abb;

    lvo_init(&lvo);
    lsobb_init(&lso);
    abb_init(&abb);

    int opcion, subopcion;

    do {
        printf("\n======================================\n");
        printf("    PADRON ELECTORAL DE SAN LUIS      \n");
        printf("======================================\n");
        printf("1. Comparacion de Estructuras\n");
        printf("2. Mostrar Estructura\n");
        printf("0. Salir\n");
        printf("Seleccione una opcion: ");
        if (scanf("%d", &opcion) != 1) break;

        switch (opcion) {
            case 1:
                ejecutar_operaciones_desde_archivo(&lvo, &lso, &abb);
                break;
            case 2:
                printf("\n--- MOSTRAR ESTRUCTURA ---\n");
                printf("1. Mostrar Lista Vinculada Ordenada (LVO)\n");
                printf("2. Mostrar Lista Secuencial Ordenada (LSOBB)\n");
                printf("3. Mostrar Arbol Binario de Busqueda (ABB Preorden)\n");
                printf("Seleccione la estructura a mostrar: ");
                scanf("%d", &subopcion);

                if (subopcion == 1) lvo_mostrar(&lvo);
                else if (subopcion == 2) lsobb_mostrar(&lso);
                else if (subopcion == 3) abb_mostrar_preorden(&abb);
                else printf("Opci�n inv�lida.\n");
                break;
            case 0:
                printf("Saliendo del programa...\n");
                break;
            default:
                printf("Opci�n no v�lida.\n");
        }
    } while (opcion != 0);

    return 0;
}
