/*
 * =====================================================================================
 * PRACTICO DE MAQUINA 1 - ESTRUCTURAS DE DATOS Y ALGORITMOS I (UNSL)
 * GRUPO: XX
 * =====================================================================================
 * RESULTADOS Y CONCLUSIONES DEL ANALISIS DE COMPARACION DE ESTRUCTURAS:
 *
 * CONCLUSIONES GENERALES:
 * 1. Consultas (Evocaciones):
 *    - LSOBB y ABB ofrecen la menor cantidad de accesos por consulta O(log N).
 *    - LVO requiere b�squeda secuencial O(N), siendo la menos eficiente para consultas.
 *
 * 2. Altas y Bajas (Modificaciones):
 *    - LVO y ABB poseen un costo de modificaci�n muy bajo (0.5 por puntero).
 *    - LSOBB tiene un costo elevado por los corrimientos contiguos de memoria (costo 1 por elemento).
 *
 * 3. Recomendaci�n:
 *    - ABB representa el mejor balance general entre consultas y modificaciones.
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "elector.h"
#include "lvo.h"
#include "lsobb.h"
#include "abb.h"

// --- FUNCIONES AUXILIARES REQUERIDAS ---

static void trim_newline(char *str) {
    size_t len = strlen(str);
    while (len > 0 && (str[len - 1] == '\n' || str[len - 1] == '\r')) {
        str[len - 1] = '\0';
        len--;
    }
}

static int comparar_cadenas_ci(const char *s1, const char *s2) {
    while (*s1 && *s2) {
        char c1 = (char)tolower((unsigned char)*s1);
        char c2 = (char)tolower((unsigned char)*s2);
        if (c1 != c2) return c1 - c2;
        s1++;
        s2++;
    }
    return (char)tolower((unsigned char)*s1) - (char)tolower((unsigned char)*s2);
}

static int comparar_electores(Elector *e1, Elector *e2) {
    char *nom1 = getNombreApellido(e1);
    char *nom2 = getNombreApellido(e2);
    char *dom1 = getDomicilio(e1);
    char *dom2 = getDomicilio(e2);

    int coincide = 1;

    if (getDni(e1) != getDni(e2)) coincide = 0;
    else if (comparar_cadenas_ci(nom1, nom2) != 0) coincide = 0;
    else if (comparar_cadenas_ci(dom1, dom2) != 0) coincide = 0;
    else if (getCodPostal(e1) != getCodPostal(e2)) coincide = 0;
    else if (getMesa(e1) != getMesa(e2)) coincide = 0;
    else if (getCircuito(e1) != getCircuito(e2)) coincide = 0;

    free(nom1); free(nom2);
    free(dom1); free(dom2);

    return coincide;
}

static void mostrar_elector(Elector *e) {
    char *nom = getNombreApellido(e);
    char *dom = getDomicilio(e);

    printf("DNI: %ld | Nombre: %s | Domicilio: %s | CP: %d | Mesa: %d | Circuito: %d\n",
           getDni(e), nom, dom, getCodPostal(e), getMesa(e), getCircuito(e));

    free(nom);
    free(dom);
}

void ejecutar_operaciones_desde_archivo(LVO *lvo, LSOBB *lso, ABB *abb) {
    FILE *f = fopen("Operaciones_Padron.txt", "r");
    char linea[200];
    float c_cons_lvo = 0, c_mod_lvo = 0;
    float c_cons_lso = 0, c_mod_lso = 0;
    float c_cons_abb = 0, c_mod_abb = 0;

    if (!f) {
        printf("Error: No se pudo abrir el archivo 'Operaciones_Padron.txt'.\n");
        return;
    }

    lvo_vaciar(lvo);
    lsobb_vaciar(lso);
    abb_vaciar(abb);

    while (fgets(linea, sizeof(linea), f)) {
        int op;
        trim_newline(linea);
        if (strlen(linea) == 0) continue;

        op = atoi(linea);
        if (op == 1 || op == 2) {
            Elector e;
            long dni;
            char nom[MAX_NOMBRE];
            char dom[MAX_DOMICILIO];
            int cp, mesa, circ;

            if (!fgets(linea, sizeof(linea), f)) break;
            dni = atol(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);
            strncpy(nom, linea, MAX_NOMBRE - 1);
            nom[MAX_NOMBRE - 1] = '\0';

            if (!fgets(linea, sizeof(linea), f)) break;
            trim_newline(linea);
            strncpy(dom, linea, MAX_DOMICILIO - 1);
            dom[MAX_DOMICILIO - 1] = '\0';

            if (!fgets(linea, sizeof(linea), f)) break;
            cp = atoi(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            mesa = atoi(linea);

            if (!fgets(linea, sizeof(linea), f)) break;
            circ = atoi(linea);

            setDni(&e, dni);
            setNombreApellido(&e, nom);
            setDomicilio(&e, dom);
            setCodPostal(&e, cp);
            setMesa(&e, mesa);
            setCircuito(&e, circ);

            if (op == 1) {
                lvo_alta(lvo, e, &c_cons_lvo, &c_mod_lvo);
                lsobb_alta(lso, e, &c_cons_lso, &c_mod_lso);
                abb_alta(abb, e, &c_cons_abb, &c_mod_abb);
            } else {
                lvo_baja(lvo, e, &c_cons_lvo, &c_mod_lvo, comparar_electores);
                lsobb_baja(lso, e, &c_cons_lso, &c_mod_lso, comparar_electores);
                abb_baja(abb, e, &c_cons_abb, &c_mod_abb, comparar_electores);
            }
        } else if (op == 3) {
            long dni;
            Elector res;
            if (!fgets(linea, sizeof(linea), f)) break;
            dni = atol(linea);

            lvo_evocacion(lvo, dni, &res, &c_cons_lvo);
            lsobb_evocacion(lso, dni, &res, &c_cons_lso);
            abb_evocacion(abb, dni, &res, &c_cons_abb);
        }
    }

    fclose(f);

    printf("\n=====================================================================\n");
    printf("                RESULTADOS DE LA COMPARACION DE COSTOS               \n");
    printf("=====================================================================\n");
    printf("%-10s | %-18s | %-18s | %-12s\n", "Estructura", "Costo Consultas", "Costo Modificac.", "Costo Total");
    printf("---------------------------------------------------------------------\n");
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "LVO", c_cons_lvo, c_mod_lvo, c_cons_lvo + c_mod_lvo);
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "LSOBB", c_cons_lso, c_mod_lso, c_cons_lso + c_mod_lso);
    printf("%-10s | %-18.2f | %-18.2f | %-12.2f\n", "ABB", c_cons_abb, c_mod_abb, c_cons_abb + c_mod_abb);
    printf("=====================================================================\n");
}

int main() {
    LVO lvo;
    LSOBB lso;
    ABB abb;
    int opcion = -1, subopcion = 0;

    lvo_init(&lvo);
    lsobb_init(&lso);
    abb_init(&abb);

    do {
        printf("\n======================================\n");
        printf("    PADRON ELECTORAL DE SAN LUIS      \n");
        printf("======================================\n");
        printf("1. Comparacion de Estructuras\n");
        printf("2. Mostrar Estructura\n");
        printf("0. Salir\n");
        printf("Seleccione una opcion: ");
        if (scanf("%d", &opcion) != 1) break;

        switch (opcion) {
            case 1:
                ejecutar_operaciones_desde_archivo(&lvo, &lso, &abb);
                break;
            case 2:
                printf("\n--- MOSTRAR ESTRUCTURA ---\n");
                printf("1. Mostrar Lista Vinculada Ordenada (LVO)\n");
                printf("2. Mostrar Lista Secuencial Ordenada (LSOBB)\n");
                printf("3. Mostrar Arbol Binario de Busqueda (ABB Preorden)\n");
                printf("Seleccione la estructura a mostrar: ");
                scanf("%d", &subopcion);

                if (subopcion == 1) lvo_mostrar(&lvo, mostrar_elector);
                else if (subopcion == 2) lsobb_mostrar(&lso, mostrar_elector);
                else if (subopcion == 3) abb_mostrar_preorden(&abb, mostrar_elector);
                else printf("Opci�n inv�lida.\n");
                break;
            case 0:
                printf("Saliendo del programa...\n");
                break;
            default:
                printf("Opci�n no v�lida.\n");
        }
    } while (opcion != 0);

    return 0;
}
