#ifndef LVO_H
#define LVO_H

#include "elector.h"

#define MAS_INFINITO 999999999

struct nodo {
    Elector dato;
    struct nodo *sig;
};

typedef struct nodo NodoLVO;

typedef struct {
    NodoLVO *head;
} LVO;

static void lvo_init(LVO *l) {
    l->head = (NodoLVO *)malloc(sizeof(NodoLVO));
    setDni(&(l->head->dato), MAS_INFINITO);
    l->head->sig = NULL;
}

static void lvo_vaciar(LVO *l) {
    NodoLVO *aux;
    NodoLVO *act = l->head;
    while (act != NULL) {
        aux = act;
        act = act->sig;
        free(aux);
    }
    lvo_init(l);
}

static int lvo_localizar(LVO *l, long dni, NodoLVO **ant, NodoLVO **act, float *costo_cons) {
    *ant = NULL;
    *act = l->head;

    while (getDni(&((*act)->dato)) < dni) {
        (*costo_cons) += 1.0f;
        *ant = *act;
        *act = (*act)->sig;
    }
    (*costo_cons) += 1.0f; // Costo del nodo donde corta (coincide o supera)

    if (getDni(&((*act)->dato)) == dni && getDni(&((*act)->dato)) < MAS_INFINITO) {
        return 1; // �xito: elemento encontrado
    }
    return 0; // Fracaso: elemento no encontrado
}

static int lvo_alta(LVO *l, Elector e, float *costo_cons, float *costo_mod) {
    NodoLVO *ant = NULL;
    NodoLVO *act = NULL;

    int existe = lvo_localizar(l, getDni(&e), &ant, &act, costo_cons);

    if (existe) {
        return 0; // Ya existe el DNI
    }

    NodoLVO *nuevo = (NodoLVO *)malloc(sizeof(NodoLVO));
    nuevo->dato = e;
    nuevo->sig = act;
    (*costo_mod) += 0.5f;

    if (ant == NULL) {
        l->head = nuevo;
    } else {
        ant->sig = nuevo;
    }
    (*costo_mod) += 0.5f;

    return 1;
}

static int lvo_baja(LVO *l, Elector e, float *costo_cons, float *costo_mod, int (*comp_fn)(Elector*, Elector*)) {
    NodoLVO *ant = NULL;
    NodoLVO *act = NULL;

    int existe = lvo_localizar(l, getDni(&e), &ant, &act, costo_cons);

    if (existe) {
        if (comp_fn(&(act->dato), &e)) {
            if (ant == NULL) {
                l->head = act->sig;
            } else {
                ant->sig = act->sig;
            }
            (*costo_mod) += 0.5f;
            free(act);
            return 1;
        }
    }
    return 0;
}

static int lvo_evocacion(LVO *l, long dni, Elector *res, float *costo_cons) {
    NodoLVO *ant = NULL;
    NodoLVO *act = NULL;

    int existe = lvo_localizar(l, dni, &ant, &act, costo_cons);

    if (existe) {
        if (res) *res = act->dato;
        return 1;
    }
    return 0;
}

static void lvo_mostrar(LVO *l, void (*imprimir_fn)(Elector*)) {
    NodoLVO *act = l->head;
    printf("\n=== LISTA VINCULADA ORDENADA (LVO) ===\n");
    while (act != NULL && getDni(&(act->dato)) != MAS_INFINITO) {
        imprimir_fn(&(act->dato));
        act = act->sig;
    }
}

#endif
