#ifndef ABB_H
#define ABB_H

#include "elector.h"

typedef struct NodoABB {
    Elector dato;
    struct NodoABB *izq;
    struct NodoABB *der;
} NodoABB;

typedef struct {
    NodoABB *raiz;
} ABB;

static void abb_init(ABB *arbol) {
    arbol->raiz = NULL;
}

static void liberar_nodos(NodoABB *r) {
    if (r != NULL) {
        liberar_nodos(r->izq);
        liberar_nodos(r->der);
        free(r);
    }
}

static void abb_vaciar(ABB *arbol) {
    liberar_nodos(arbol->raiz);
    arbol->raiz = NULL;
}

static int abb_alta(ABB *arbol, Elector e, float *costo_cons, float *costo_mod) {
    NodoABB **act = &(arbol->raiz);

    while (*act != NULL) {
        (*costo_cons) += 1.0f;
        if (getDni(&((*act)->dato)) == getDni(&e)) return 0;

        if (getDni(&e) < getDni(&((*act)->dato))) {
            act = &((*act)->izq);
        } else {
            act = &((*act)->der);
        }
    }

    NodoABB *nuevo = (NodoABB *)malloc(sizeof(NodoABB));
    nuevo->dato = e;
    nuevo->izq = NULL;
    nuevo->der = NULL;

    *act = nuevo;
    (*costo_mod) += 0.5f;

    return 1;
}

static NodoABB* extraer_menor_de_los_mayores(NodoABB **r, float *costo_cons, float *costo_mod) {
    NodoABB **act = r;
    while ((*act)->izq != NULL) {
        (*costo_cons) += 1.0f;
        act = &((*act)->izq);
    }
    (*costo_cons) += 1.0f;

    NodoABB *min = *act;
    *act = min->der;
    (*costo_mod) += 0.5f;

    return min;
}

static int abb_baja(ABB *arbol, Elector e, float *costo_cons, float *costo_mod, int (*comp_fn)(Elector*, Elector*)) {
    NodoABB **act = &(arbol->raiz);

    while (*act != NULL) {
        (*costo_cons) += 1.0f;
        if (getDni(&((*act)->dato)) == getDni(&e)) break;

        if (getDni(&e) < getDni(&((*act)->dato))) {
            act = &((*act)->izq);
        } else {
            act = &((*act)->der);
        }
    }

    if (*act == NULL) return 0;

    if (!comp_fn(&((*act)->dato), &e)) return 0;

    NodoABB *a_eliminar = *act;

    if (a_eliminar->izq == NULL) {
        *act = a_eliminar->der;
        (*costo_mod) += 0.5f;
        free(a_eliminar);
    } else if (a_eliminar->der == NULL) {
        *act = a_eliminar->izq;
        (*costo_mod) += 0.5f;
        free(a_eliminar);
    } else {
        NodoABB *reemplazo = extraer_menor_de_los_mayores(&(a_eliminar->der), costo_cons, costo_mod);
        a_eliminar->dato = reemplazo->dato; // Copia de datos
        (*costo_mod) += 1.0f;               // Costo adicional 1
        free(reemplazo);
    }

    return 1;
}

static int abb_evocacion(ABB *arbol, long dni, Elector *res, float *costo_cons) {
    NodoABB *act = arbol->raiz;

    while (act != NULL) {
        (*costo_cons) += 1.0f;
        if (getDni(&(act->dato)) == dni) {
            if (res) *res = act->dato;
            return 1;
        }
        if (dni < getDni(&(act->dato))) {
            act = act->izq;
        } else {
            act = act->der;
        }
    }
    return 0;
}

static void preorden_recursivo(NodoABB *r, void (*imprimir_fn)(Elector*)) {
    if (r == NULL) return;

    printf("\n[NODO DNI: %ld]\n", getDni(&(r->dato)));
    imprimir_fn(&(r->dato));

    if (r->izq != NULL) {
        printf("  -> Hijo Izquierdo DNI: %ld\n", getDni(&(r->izq->dato)));
    } else {
        printf("  -> Hijo Izquierdo: No tiene\n");
    }

    if (r->der != NULL) {
        printf("  -> Hijo Derecho DNI: %ld\n", getDni(&(r->der->dato)));
    } else {
        printf("  -> Hijo Derecho: No tiene\n");
    }

    preorden_recursivo(r->izq, imprimir_fn);
    preorden_recursivo(r->der, imprimir_fn);
}

static void abb_mostrar_preorden(ABB *arbol, void (*imprimir_fn)(Elector*)) {
    printf("\n=== ARBOL BINARIO DE BUSQUEDA (ABB) - PREORDEN ===\n");
    if (arbol->raiz == NULL) {
        printf("El �rbol est� vac�o.\n");
    } else {
        preorden_recursivo(arbol->raiz, imprimir_fn);
    }
}

#endif
