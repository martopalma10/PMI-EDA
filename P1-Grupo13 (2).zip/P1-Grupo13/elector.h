#ifndef ELECTOR_H
#define ELECTOR_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_NOMBRE 51
#define MAX_DOMICILIO 81

typedef struct {
    long dni;
    char nombreApellido[MAX_NOMBRE];
    char domicilio[MAX_DOMICILIO];
    int codPostal;
    int mesa;
    int circuito;
} Elector;

// -- SETTERS --

void setDni (Elector *e, long dni){
    e->dni = dni;
}

void setNombreApellido (Elector *e, char nombreApellido[MAX_NOMBRE]){
    strcpy(e->nombreApellido, nombreApellido);
}

void setDomicilio (Elector *e, char domicilio[MAX_DOMICILIO]){
    strcpy(e->domicilio, domicilio);
}

void setCodPostal (Elector *e, int codPostal){
    e->codPostal = codPostal;
}

void setMesa (Elector *e, int mesa){
    e->mesa = mesa;
}

void setCircuito (Elector *e, int circuito){
    e->circuito = circuito;
}

// GETTERS

long getDni (Elector *e){
    return e->dni;
}

char* getNombreApellido (Elector *e){
    char *nombre;
    nombre = (char*)malloc(strlen(e->nombreApellido) + 1);
    if(nombre==NULL) exit(1);
    else{
        strcpy(nombre, e->nombreApellido);
        return nombre;
    }
}

char* getDomicilio (Elector *e){
    char *domicilio;
    domicilio = (char*)malloc(strlen(e->domicilio) + 1);
    if(domicilio==NULL) exit(1);
    else{
        strcpy(domicilio, e->domicilio);
        return domicilio;
    }
}

int getCodPostal (Elector *e){
    return e->codPostal;
}

int getMesa (Elector *e){
    return e->mesa;
}

int getCircuito (Elector *e){
    return e->circuito;
}


#endif
