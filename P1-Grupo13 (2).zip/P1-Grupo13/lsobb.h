#ifndef LSOBB_H
#define LSOBB_H
#include "elector.h"
#define MAX_LSO 2500  //Se estiman 2000 pero no dice 2000 estricto

typedef struct {
    Elector datos[MAX_LSO];
    int cant;
} LSOBB;

float costoSuma_LSO_cons = 0;
float costoSuma_LSO_mod = 0;

// ALTA
static float maximoAltaSOBB = 0.0f;
static int cantidadAltaSOBB = 0;
static float acumuladoAltaSOBB = 0.0f;

// BAJA
static float maximoBajaSOBB = 0.0f;
static int cantidadBajaSOBB = 0;
static float acumuladoBajaSOBB = 0.0f;

// EVOCACION EXITOSA Y FRACASO
static float maximoEvoExitoSOBB = 0.0f;
static int cantidadEvoExitoSOBB = 0;
static float acumuladoEvoExitoSOBB = 0.0f;

static float maximoEvoFracasoSOBB = 0.0f;
static int cantidadEvoFracasoSOBB = 0;
static float acumuladoEvoFracasoSOBB = 0.0f;

// Funciones auxiliares de actualizaci�n de m�tricas
static void actualizarMedicionesAltaListaSOBB(float costoOperacion) {
    cantidadAltaSOBB++;
    acumuladoAltaSOBB += costoOperacion;
    if (costoOperacion > maximoAltaSOBB) maximoAltaSOBB = costoOperacion;
}

static void actualizarMedicionesBajaListaSOBB(float costoOperacion) {
    cantidadBajaSOBB++;
    acumuladoBajaSOBB += costoOperacion;
    if (costoOperacion > maximoBajaSOBB) maximoBajaSOBB = costoOperacion;
}

static void actualizarMedicionesEvocacionListaSOBB(float costoOperacion, int exito) {
    if (exito) {
        cantidadEvoExitoSOBB++;
        acumuladoEvoExitoSOBB += costoOperacion;
        if (costoOperacion > maximoEvoExitoSOBB) maximoEvoExitoSOBB = costoOperacion;
    } else {
        cantidadEvoFracasoSOBB++;
        acumuladoEvoFracasoSOBB += costoOperacion;
        if (costoOperacion > maximoEvoFracasoSOBB) maximoEvoFracasoSOBB = costoOperacion;
    }
}

// Getters de m�tricas para la tabla final
static float getMediaAltaListaSOBB() { return cantidadAltaSOBB == 0 ? 0.0f : (acumuladoAltaSOBB / cantidadAltaSOBB); }
static float getMaximoAltaListaSOBB() { return maximoAltaSOBB; }

static float getMediaBajaListaSOBB() { return cantidadBajaSOBB == 0 ? 0.0f : (acumuladoBajaSOBB / cantidadBajaSOBB); }
static float getMaximoBajaListaSOBB() { return maximoBajaSOBB; }

static float getMediaEvoExitoListaSOBB() { return cantidadEvoExitoSOBB == 0 ? 0.0f : (acumuladoEvoExitoSOBB / cantidadEvoExitoSOBB); }
static float getMaximoEvoExitoListaSOBB() { return maximoEvoExitoSOBB; }

static float getMediaEvoFracasoListaSOBB() { return cantidadEvoFracasoSOBB == 0 ? 0.0f : (acumuladoEvoFracasoSOBB / cantidadEvoFracasoSOBB); }
static float getMaximoEvoFracasoListaSOBB() { return maximoEvoFracasoSOBB; }

void lsobb_reset_metricas(void) {
    maximoAltaSOBB = 0.0f;
    cantidadAltaSOBB = 0;
    acumuladoAltaSOBB = 0.0f;

    maximoBajaSOBB = 0.0f;
    cantidadBajaSOBB = 0;
    acumuladoBajaSOBB = 0.0f;

    maximoEvoExitoSOBB = 0.0f;
    cantidadEvoExitoSOBB = 0;
    acumuladoEvoExitoSOBB = 0.0f;

    maximoEvoFracasoSOBB = 0.0f;
    cantidadEvoFracasoSOBB = 0;
    acumuladoEvoFracasoSOBB = 0.0f;
}

// --- INICIALIZAR ---
void lsobb_init(LSOBB *l) {
    l->cant = 0;
}

// --- VACIAR ---
void lsobb_vaciar(LSOBB *l) {
    l->cant = 0;
}

// --- LOCALIZAR ---
// B�squeda binaria (Bisecci�n con l�mites inclusivos).
// Devuelve 1 si encuentra el DNI (�xito) y guarda en 'pos' su �ndice.
// Devuelve 0 si no lo encuentra (fracaso) y guarda en 'pos' el �ndice de inserci�n.
// --- LOCALIZAR CON VECTOR DE MARCA (CORREGIDO) ---
// Devuelve 1 si encuentra el DNI (�xito) y guarda en 'pos' su �ndice.
// Devuelve 0 si no lo encuentra (fracaso) y guarda en 'pos' el �ndice de inserci�n.
int lsobb_localizar(LSOBB *l, long dni, int *pos, float *costo_cons) {
    int vectorMarca[MAX_LSO] = {0}; // Inicializaci�n en cero
    int li = 0, ls = l->cant - 1;
    int testigo = 0;
    *costo_cons = 0.0f;

    // Estructura vac�a
    if (l->cant == 0) {
        *pos = 0;
        return 0;
    }

    // Bucle de Bisecci�n (Testigo a izquierda)
    while (li < ls) {
        testigo = (li + ls) / 2;

        // Solo incrementa costo si la celda 'testigo' no fue evaluada previamente
        if (vectorMarca[testigo] == 0) {
            (*costo_cons) += 1.0f;
            vectorMarca[testigo] = 1;
        }

        if (dni <= getDni(&(l->datos[testigo]))) {
            ls = testigo;
        } else {
            li = testigo + 1;
        }
    }

    // Al salir del bucle li == ls.
    // Se verifica si la celda final 'li' ya fue cobrada/marcada en alguna iteraci�n previa
    if (vectorMarca[li] == 0) {
        (*costo_cons) += 1.0f;
        vectorMarca[li] = 1;
    }

    // Evaluaci�n sobre 'li' (nunca sobre 'testigo')
    if (dni == getDni(&(l->datos[li]))) {
        *pos = li;
        return 1; // �xito
    } else {
        if (dni > getDni(&(l->datos[li]))) {
            *pos = li + 1;
        } else {
            *pos = li;
        }
        return 0; // Fracaso (posicion de inserci�n)
    }
}
// --- ALTA ---
int lsobb_alta(LSOBB *l, Elector e, float *costo_cons, float *costo_mod) {
    int pos, i;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    if (l->cant >= MAX_LSO) {
        return 0; // Lista llena
    }

    int existe = lsobb_localizar(l, getDni(&e), &pos, costo_cons);

    if (existe) {
        return 0; // Ya existe la clave (no se admiten duplicados)
    }

    // Corrimiento de elementos a la derecha para generar el espacio
    for (i = l->cant; i > pos; i--) {
        l->datos[i] = l->datos[i - 1];
        (*costo_mod) += 1.0f; // Cada corrimiento suma 1 de costo
    }

    l->datos[pos] = e;
    l->cant++;

    // Actualizaci�n autom�tica de m�tricas (solo corrimientos)
    actualizarMedicionesAltaListaSOBB(*costo_mod);

    return 1;
}

// --- BAJA ---
int lsobb_baja(LSOBB *l, Elector e, float *costo_cons, float *costo_mod, int (*comp_fn)(Elector*, Elector*)) {
    int pos, i;
    *costo_cons = 0.0f;
    *costo_mod = 0.0f;

    int existe = lsobb_localizar(l, getDni(&e), &pos, costo_cons);

    if (existe) {
        // Confirmaci�n de la baja por toda la nupla
        if (comp_fn(&(l->datos[pos]), &e)) {
            // Corrimiento de elementos a la izquierda
            for (i = pos; i < l->cant - 1; i++) {
                l->datos[i] = l->datos[i + 1];
                (*costo_mod) += 1.0f; // Cada corrimiento suma 1 de costo
            }
            l->cant--;

            // Actualizaci�n autom�tica de m�tricas (solo corrimientos)
            actualizarMedicionesBajaListaSOBB(*costo_mod);

            return 1;
        }
    }
    return 0;
}

// --- EVOCACI�N ---
int lsobb_evocacion(LSOBB *l, long dni, Elector *res, float *costo_cons) {
    int pos;
    *costo_cons = 0.0f;

    int existe = lsobb_localizar(l, dni, &pos, costo_cons);

    if (existe) {
        if (res) *res = l->datos[pos];

        // Actualizaci�n autom�tica de m�tricas (�xito)
        actualizarMedicionesEvocacionListaSOBB(*costo_cons, 1);
        return 1;
    }

    // Actualizaci�n autom�tica de m�tricas (fracaso)
    actualizarMedicionesEvocacionListaSOBB(*costo_cons, 0);
    return 0;
}

// --- MOSTRAR ---
void lsobb_mostrar(LSOBB *l, void (*imprimir_fn)(Elector*)) {
    int i;
    int contador = 0; // Se inicializa el contador de paginaci�n
    char respuesta;

    printf("\n=== LISTA SECUENCIAL ORDENADA (LSOBB) ===\n");
    for (i = 0; i < l->cant; i++) {
        imprimir_fn(&(l->datos[i]));

        contador++;
        // L�gica de paginaci�n cada 10 electores
        if (contador % 10 == 0) {
            printf("\n�Desea ver 10 electores m�s? (s/n): ");
            scanf(" %c", &respuesta);
            if (respuesta == 'n' || respuesta == 'N') {
                break;
            }
        }
    }
}

#endif
